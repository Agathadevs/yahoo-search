import setuptools

setuptools.setup(
    name = "yahoosearcher-py",                                                                                                                              
    version = "0.0.1",
    author = "Cheng",
    license='MIT license',
    author_email="kimichen2907@gmail.com",
    description="search news,videos,weathers from yahoo",
    url="https://github.com/ditisrmel/yahoo-search", 
    python_requires='>=3.11.4'
)